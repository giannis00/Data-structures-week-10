class Stack:
    def __init__(self):
        self._stack = []     # use a python list to maintain the stack
        self._size = 0

    def __str__(self):
        desc = ""
        for x in reversed(self._stack):
            desc += f"| {x} |\n"
        desc += f"-----"
        return desc

    def pop(self):
        if not self.is_empty():
            self._size -= 1
            return self._stack.pop()
    
    def push(self, x):
        self._size += 1
        self._stack.append(x)

    def is_empty(self):
        return self._size == 0

    def peek(self):
        if not self.is_empty():
            return self._stack[-1]
        

if __name__ == "__main__":
    stack1 = Stack()
    stack1.push(1)
    stack1.push(2)
    stack1.push(3)
    print(stack1)
    print(stack1.is_empty())
    print(stack1.peek())
    stack1.pop()
    print(stack1)
    stack1.pop()
    print(stack1)
    stack1.pop()
    print(stack1)
    print(stack1.is_empty())
    print(stack1.peek())