from doubly_linked_list import DoublyLinkedList

class Queue:
    def __init__(self):
        self._queue = DoublyLinkedList()

    def __str__(self):
        current_node = self._queue.head
        output = ["Front --   "]
        while current_node != None:
            output.append(str(current_node.data))
            current_node = current_node.next

        if output:
            return " | ".join(output) + f"    -- Back \n Size = {self.size()}"
        else:
            return "Empty Queue"

    def enqueue(self, x):
        self._queue.insert_last(x)

    def dequeue(self):
        if not self.is_empty():
            first_item = self.peek()
            self._queue.delete_first()
            return first_item

    def is_empty(self):
        return self.size() == 0

    def peek(self):
        if not self.is_empty():
            return self._queue.head.data
        
    def size(self):
        return self._queue._size

if __name__ == "__main__":
    queue1 = Queue()
    queue1.enqueue(5)
    queue1.enqueue(10)
    queue1.enqueue(44)
    print(queue1.peek())
    print(queue1)
    queue1.dequeue()
    print(queue1)
    queue1.dequeue()
    print(queue1)